package com.example.acer.bookapiloaders;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

public class DetailsActivity extends AppCompatActivity {
ImageView imageView;
TextView textView;
RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
    imageView=findViewById(R.id.img);
    textView=findViewById(R.id.tv);
recyclerView=findViewById(R.id.rv);
    String title=getIntent().getStringExtra("t");
    String author=getIntent().getStringExtra("a");
        Toast.makeText(this, title+"\n"+author, Toast.LENGTH_SHORT).show();
    String imageLink=getIntent().getStringExtra("im");
       Picasso.with(this).load(imageLink).into(imageView);
       Toast.makeText(this, ""+title+""+author+""+imageLink, Toast.LENGTH_SHORT).show();
textView.setText(title+"\n" +author+"\n");

    }
}
