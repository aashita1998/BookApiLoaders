package com.example.acer.bookapiloaders;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.Loader;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<String> {
    TextView title, author;
    EditText editText;
    Button button;
    ImageView imageView;
    ArrayList<Book> list;
    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // title=findViewById(R.id.textView1);
        //author=findViewById(R.id.textView2);
        editText = findViewById(R.id.et1);
        button = findViewById(R.id.button);
        imageView = findViewById(R.id.image);
        recyclerView = findViewById(R.id.rv);
    }

    public void search(View view) {
        String book = editText.getText().toString();
        Bundle b = new Bundle();
        b.putString("key", book);
        getSupportLoaderManager().restartLoader(1, b, MainActivity.this);
    }

    @NonNull
    @Override
    public Loader<String> onCreateLoader(int id, @Nullable Bundle args) {
        String data = args.getString("key");
        list = new ArrayList<Book>();

        return new MyAsc(this, data);
    }

    @Override
    public void onLoadFinished(@NonNull Loader<String> loader, String data) {
      //  Toast.makeText(this, data, Toast.LENGTH_SHORT).show();
        try {
            JSONObject object = new JSONObject(data);
            JSONArray array = object.getJSONArray("items");
            StringBuilder builder = new StringBuilder();
            String title = null;
            String author = null;
            String imageLinks = null;
            for (int i = 0; i < array.length(); i++) {
                JSONObject object1 = array.getJSONObject(i);
                JSONObject object2 = object1.getJSONObject("volumeInfo");
                title = object2.getString("title");
                author = object2.getString("authors");
                JSONObject image = object2.getJSONObject("imageLinks");
                imageLinks = image.getString("thumbnail");

                // builder.append(title);
                // builder.append(author);

                Book books = new Book(title, author, imageLinks);

                list.add(books);
                Log.d("list",list.toString());
            }

            //title.setText(books.getTitle());
            //author.setText(books.getTitle());

        } catch (JSONException e) {
            e.printStackTrace();
        }
        MyAdapter myAdapter = new MyAdapter(this, list);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(myAdapter);


    }

    @Override
    public void onLoaderReset(@NonNull Loader<String> loader) {

    }
}
