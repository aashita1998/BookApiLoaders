package com.example.acer.bookapiloaders;

public class Book {
    public String Title;
    public String Author;
    public String ImageLinks;

    public Book() {

    }

    public Book(String title, String author, String imageLinks) {
        Title = title;
        Author = author;
        ImageLinks = imageLinks;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public String getAuthor() {
        return Author;
    }

    public void setAuthor(String author) {
        Author = author;
    }

    public String getImageLinks() {
        return ImageLinks;
    }

    public void setImageLinks(String imageLinks) {
        ImageLinks = imageLinks;
    }
}
