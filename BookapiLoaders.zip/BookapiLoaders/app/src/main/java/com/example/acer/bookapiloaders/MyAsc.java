package com.example.acer.bookapiloaders;

import android.net.Uri;
import android.support.annotation.Nullable;
import android.support.v4.content.AsyncTaskLoader;
import android.support.v4.content.Loader;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

class MyAsc extends AsyncTaskLoader<String> {
    String mydata;
    public static final String link="https://www.googleapis.com/books/v1/volumes?";
    public static final String query="q";
    public static final String max="max";
    public static final String print_type="printType";
    public MyAsc(MainActivity mainActivity, String data) {
        super(mainActivity);
        mydata=data;
    }

    @Override
    protected void onStartLoading() {
        super.onStartLoading();
        forceLoad();
    }

    @Nullable
    @Override
    public String loadInBackground() {
        Uri uri=Uri.parse(link).buildUpon()
                .appendQueryParameter(query,mydata)
                .appendQueryParameter(max,"10")
                .appendQueryParameter(print_type,"books").build();
        try {
            URL url=new URL(uri.toString());
            HttpURLConnection connection= (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.connect();
            InputStream inputStream=connection.getInputStream();
            BufferedReader bufferedReader=new BufferedReader(new InputStreamReader(inputStream));
            StringBuilder stringBuilder=new StringBuilder();
            String line="";
            while ((line=bufferedReader.readLine())!=null){
                stringBuilder.append(line);
            }
            return  stringBuilder.toString();


        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
